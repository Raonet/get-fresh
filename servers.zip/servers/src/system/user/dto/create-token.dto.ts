export class CreateTokenDto {
  accessToken: string
  refreshToken: string
}
